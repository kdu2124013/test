import MyInfo from "./_components/MyInfo";

const MyPage = () => {
  return (
    <div>
      <MyInfo />
    </div>
  );
};

export default MyPage;
