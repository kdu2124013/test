import FindPassword from "../../_components/FindPassword";

const FindPasswordPage = () => {
  return <FindPassword />;
};

export default FindPasswordPage;
