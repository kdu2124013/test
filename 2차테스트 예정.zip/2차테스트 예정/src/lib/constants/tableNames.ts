export const USERS_TABLE = "users";
export const TODOS_TABLE = "todos";
export const DIARY_TABLE = "diaries";
export const CHAT_SESSIONS = "chat_sessions";
