export const queryKeys = {
  chat: "chat_sessions" as const
};
