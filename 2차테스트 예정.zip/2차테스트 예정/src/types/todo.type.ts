import { Tables } from "./supabase";

export type Todo = Tables<"todos">;
