declare module "dompurify" {
  const DOMPurify: any;
  export default DOMPurify;
}
