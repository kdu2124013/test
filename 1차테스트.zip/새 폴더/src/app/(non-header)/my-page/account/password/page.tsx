import EditPassword from "../../_components/EditPassword";

const EditPasswordPage = () => {
  return <EditPassword />;
};

export default EditPasswordPage;
