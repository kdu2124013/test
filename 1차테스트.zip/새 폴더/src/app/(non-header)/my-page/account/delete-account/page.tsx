import DeleteAccount from "../../_components/DeleteAccount";

const DeleteAccountPage = () => {
  return <DeleteAccount />;
};

export default DeleteAccountPage;
