"use client";

import dayjs from "dayjs";
import "dayjs/locale/ko";
import { Todo } from "../../../../types/todo.type";
import { TodoFormData } from "./TodoForm";
import TodoList from "./TodoList";
import useModal from "@/hooks/useModal";
import CheckIcon from "@/components/icons/todo-list/Check";
import CircleCheckFill from "@/components/icons/todo-list/CircleCheckFill";
import ThumbUp from "@/components/icons/todo-list/ThumbUp";
import { useAddTodo } from "../../../../hooks/useAddTodo";
import { useTodos } from "../../../../hooks/useTodos";
import QuickAddTodoForm from "./QuickAddTodoForm";
import { useState, useEffect } from "react";
import { Button } from "@/components/button";
import { toast } from "react-toastify";
import { LocationData } from "@/types/location.type";

interface TodoListContainerProps {
  todos: Todo[];
  selectedDate: Date;
  onSubmit?: (data: TodoFormData) => Promise<void>;
}

const TodoListContainer = ({ todos, selectedDate, onSubmit }: TodoListContainerProps) => {
  // const [editingTodo, setEditingTodo] = useState<Todo>();
  const [isDesktop, setIsDesktop] = useState(false);
  const { Modal, openModal } = useModal();
  const { handleAddTodoSubmit } = useAddTodo(selectedDate);
  const { deleteTodo, addTodo } = useTodos(todos[0]?.user_id ?? "");

  useEffect(() => {
    const updateIsDesktop = () => {
      setIsDesktop(window.innerWidth >= 1200);
    };
    updateIsDesktop();

    window.addEventListener("resize", updateIsDesktop);

    return () => window.removeEventListener("resize", updateIsDesktop);
  }, []);

  dayjs.locale("ko");

  // refactoring to be : TodoList.tsx로 로직 이동, 애는 Container의 역할만 하도록 분리하기
  const sortTodos = (a: Todo, b: Todo) => {
    const getDate = (todo: Todo) => {
      return todo.is_all_day_event === false
        ? new Date(todo.event_datetime ?? todo.created_at)
        : new Date(todo.created_at);
    };

    if (a.is_all_day_event !== b.is_all_day_event) {
      return a.is_all_day_event ? 1 : -1;
    }

    const dateA = getDate(a);
    const dateB = getDate(b);

    return dateA.getTime() - dateB.getTime();
  };

  const todayTodos = todos
    .filter((todo) => !todo.is_done && dayjs(todo.event_datetime).isSame(selectedDate, "day"))
    .sort(sortTodos);

  const completedTodayTodos = todos
    .filter((todo) => todo.is_done && dayjs(todo.event_datetime).isSame(selectedDate, "day"))
    .sort(sortTodos);

  const isAllCompleted = todayTodos.length === 0 && completedTodayTodos.length > 0;

  // const handleEditClick = (todo: Todo) => {
  //   setEditingTodo(todo);
  // };

  const handleCopyToLastWeek = async () => {
    // 전주 같은 날짜의 일정 가져오기
    const lastWeekDate = dayjs(selectedDate).subtract(7, 'day');
    const lastWeekTodos = todos.filter(todo => 
      dayjs(todo.event_datetime).isSame(lastWeekDate, 'day')
    );

    try {
      for (const todo of lastWeekTodos) {
        const address = todo.address as LocationData | null;
        const eventTime = todo.event_datetime 
          ? [dayjs(todo.event_datetime).hour(), dayjs(todo.event_datetime).minute()] as [number, number]
          : null;
        const eventDateTime = eventTime 
          ? dayjs(selectedDate).hour(eventTime[0]).minute(eventTime[1]).toISOString()
          : dayjs(selectedDate).set("hour", 0).set("minute", 0).toISOString();

        await addTodo({
          todo_title: todo.todo_title ?? "",
          todo_description: todo.todo_description ?? "",
          event_datetime: eventDateTime,
          address: address ?? undefined,
          is_chat: false,
          is_all_day_event: eventTime === null
        });
      }
      toast.success('전주 같은 날짜의 일정이 복사되었습니다.');
    } catch (error) {
      toast.error('일정 복사 중 오류가 발생했습니다.');
    }
  };

  const handleCopyAllToLastWeek = async () => {
    // 이전 주의 시작일과 종료일 계산
    const currentWeekStart = dayjs(selectedDate).startOf('week');
    const lastWeekStart = currentWeekStart.subtract(1, 'week');
    const lastWeekEnd = lastWeekStart.add(6, 'day');

    // 이전 주의 모든 일정 가져오기
    const lastWeekTodos = todos.filter(todo => {
      const todoDate = dayjs(todo.event_datetime);
      return todoDate.isAfter(lastWeekStart) && todoDate.isBefore(lastWeekEnd.add(1, 'day'));
    });

    // 현재 주의 시작일부터 일정 복사
    try {
      for (let i = 0; i < 7; i++) {
        const targetDate = currentWeekStart.add(i, 'day');
        const sourceDate = lastWeekStart.add(i, 'day');
        
        // 해당 요일의 일정만 필터링
        const dayTodos = lastWeekTodos.filter(todo => 
          dayjs(todo.event_datetime).isSame(sourceDate, 'day')
        );

        // 일정 복사
        for (const todo of dayTodos) {
          const address = todo.address as LocationData | null;
          const eventTime = todo.event_datetime 
            ? [dayjs(todo.event_datetime).hour(), dayjs(todo.event_datetime).minute()] as [number, number]
            : null;
          const eventDateTime = eventTime 
            ? dayjs(targetDate).hour(eventTime[0]).minute(eventTime[1]).toISOString()
            : dayjs(targetDate).set("hour", 0).set("minute", 0).toISOString();

          await addTodo({
            todo_title: todo.todo_title ?? "",
            todo_description: todo.todo_description ?? "",
            event_datetime: eventDateTime,
            address: address ?? undefined,
            is_chat: false,
            is_all_day_event: eventTime === null
          });
        }
      }
      toast.success('이전 주의 일정이 복사되었습니다.');
    } catch (error) {
      toast.error('일정 복사 중 오류가 발생했습니다.');
    }
  };

  const handleDeleteAll = async () => {
    try {
      const allTodos = [...todayTodos, ...completedTodayTodos];
      for (const todo of allTodos) {
        await deleteTodo(todo.todo_id);
      }
      toast.success('모든 일정이 삭제되었습니다.');
    } catch (error) {
      toast.error('일정 삭제 중 오류가 발생했습니다.');
    }
  };

  const TodoListNode = (
    <>
      <div className="flex gap-2 mb-4">
        <Button
          variant="linedPAI"
          onClick={handleCopyToLastWeek}
          className="text-sm"
        >
          전주 요일 복사
        </Button>
        <Button
          variant="linedPAI"
          onClick={handleCopyAllToLastWeek}
          className="text-sm"
        >
          전주 전체 복사
        </Button>
        <Button
          variant="linedGrayScale"
          onClick={() => openModal({
            message: "모든 일정을 삭제하시겠습니까?\n이 작업은 되돌릴 수 없습니다.",
            confirmButton: {
              text: "삭제",
              style: "bg-pai-400 hover:bg-pai-300 text-system-white"
            },
            cancelButton: {
              text: "취소",
              style: "bg-gray-100 hover:bg-gray-200 text-gray-700"
            }
          }, handleDeleteAll)}
          className="text-sm"
        >
          전체 삭제
        </Button>
      </div>
      <TodoList
        // onClick={handleEditClick}
        todos={todayTodos}
        title={<h2 className="text-sh4 text-pai-700">오늘 할 일</h2>}
        className="desktop:border-2 desktop:border-pai-400"
        contents={
          isAllCompleted ? (
            <div className="flex items-center w-full min-w-[19.9375rem] px-[1.25rem] py-[1rem] rounded-full bg-pai-400">
              <ThumbUp className="w-[1.25rem] h-[1.25rem] mr-[0.75rem] text-system-white" />
              <p className="text-bc4 text-system-white">와우~ 할 일을 모두 완료하셨어요!</p>
            </div>
          ) : (
            <div className="flex items-center w-full min-w-[19.9375rem] px-[1.25rem] py-[1rem] rounded-full bg-gray-100">
              <CheckIcon className="w-[1.25rem] h-[1.25rem] mr-[0.75rem] text-gray-400" />
              <p className="text-bc4 text-gray-400">작성된 투두리스트가 없습니다</p>
            </div>
          )
        }
        inlineForm={<QuickAddTodoForm onSubmit={handleAddTodoSubmit} />}
      />

      <TodoList
        // onClick={handleEditClick}
        todos={completedTodayTodos}
        title={<h2 className="text-sh4 text-gray-700">완료한 일</h2>}
        className="desktop:border-2 desktop:border-gray-400"
        contents={
          completedTodayTodos.length === 0 ? (
            <div className="flex items-center w-full min-w-[19.9375rem] px-[1.25rem] py-[1rem] rounded-full bg-gray-100">
              <CircleCheckFill className="w-[1.25rem] h-[1.25rem] mr-[0.75rem] text-gray-400" />
              <p className="text-bc4 text-gray-400">완성된 투두리스트가 없습니다</p>
            </div>
          ) : null
        }
      />
    </>
  );

  return (
    <>
      <Modal />
      <div className="flex flex-col w-full h-full mobile:pb-[100px] px-4 gap-[1.25rem] desktop:gap-[2rem] desktop:p-0">
        {isDesktop ? (
          <>
            <div className="flex flex-col w-full h-full px-4 gap-[1.25rem] desktop:gap-[2rem] desktop:p-0 rounded-t-[5.63rem] bg-system-white bg-gradient-to-b">
              <div className="flex flex-col items-start self-stretch h-full">
                <div className="w-full flex flex-col items-center gap-[0.625rem] px-[3.25rem] py-[1.75rem]">
                  <p className="text-bc2 text-pai-900">{dayjs(selectedDate).format("YYYY년 M월 D일 ddd요일")}</p>
                </div>
                <div className="w-full bg-gradient-to-b flex flex-col gap-[2rem] px-[2.75rem] py-[2rem] pb-[78px] overflow-y-auto scrollbar-hide scrollbar-smooth">
                  {TodoListNode}
                </div>
              </div>
            </div>
          </>
        ) : (
          TodoListNode
        )}
        {/* <EditTodoDrawer todo={editingTodo} onClose={() => setEditingTodo(undefined)} /> */}
      </div>
    </>
  );
};

export default TodoListContainer;
