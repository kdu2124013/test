import { AIType } from "@/types/chat.session.type";

export const AI_TYPES: AIType[] = ["assistant", "friend"];
