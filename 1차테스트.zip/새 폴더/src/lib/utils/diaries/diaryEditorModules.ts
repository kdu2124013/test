const modules = {
  toolbar: {
    container: [
      ["image","bold", "italic", "underline"],
      ["strike"],
      [{ color: [] }, { background: [] }],
      [{ align: "", }, { align: "center" }, { align: "right" }],
      [{ list: "check" }],
    ]
  }
};

export default modules;
