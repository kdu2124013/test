const Loading = () => {
  return (
    <>
      <span className="pai-loader"></span>
    </>
  );
};

export default Loading;
