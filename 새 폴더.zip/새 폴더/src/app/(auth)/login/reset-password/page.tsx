import ResetPassword from "../../_components/ResetPassword";

const ResetPasswordPage = () => {
  return <ResetPassword />;
};

export default ResetPasswordPage;
