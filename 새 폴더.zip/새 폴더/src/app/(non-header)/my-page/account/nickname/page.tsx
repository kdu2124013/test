import EditNickname from "../../_components/EditNickname";

const EditNicknamePage = () => {
  return <EditNickname />;
};

export default EditNicknamePage;
