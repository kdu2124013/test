import { Tables } from "./supabase";

export type User = Tables<"users">;
