// import Modal from "react-modal";

// Modal.setAppElement("#__next");

// const AddTodoModal = () => {
//   return <Modal>모달</Modal>;
// };

// export default AddTodoModal;
