export type TransactionType = 'income' | 'expense';

export type TransactionCategory = 
  | 'salary' 
  | 'investment' 
  | 'food' 
  | 'transportation' 
  | 'shopping' 
  | 'entertainment' 
  | 'utilities' 
  | 'other';

export interface FinancialEntry {
  amount: number;
  type: TransactionType;
  category: TransactionCategory;
  description?: string;
}

export interface DiaryEntry {
  id: string;
  userId: string;
  content: string;
  date: string;
  mood?: string;
  weather?: string;
  financial?: FinancialEntry;
  createdAt: string;
  updatedAt: string;
}

export interface DiaryStatistics {
  totalIncome: number;
  totalExpense: number;
  netAmount: number;
  categoryBreakdown: Record<TransactionCategory, number>;
  periodStart: string;
  periodEnd: string;
} 