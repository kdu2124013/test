import React from 'react';
import { FinancialEntry, TransactionCategory, TransactionType } from '@/types/diary';

interface FinancialEntryFormProps {
  value: FinancialEntry;
  onChange: (value: FinancialEntry) => void;
}

const categories: TransactionCategory[] = [
  'salary',
  'investment',
  'food',
  'transportation',
  'shopping',
  'entertainment',
  'utilities',
  'other'
];

export const FinancialEntryForm: React.FC<FinancialEntryFormProps> = ({
  value,
  onChange
}) => {
  const handleChange = (field: keyof FinancialEntry, newValue: any) => {
    onChange({
      ...value,
      [field]: newValue
    });
  };

  return (
    <div className="space-y-4 p-4 border rounded-lg bg-white/5">
      <h3 className="text-lg font-semibold">Financial Entry</h3>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Type</label>
          <select
            className="w-full p-2 rounded border bg-transparent"
            value={value.type}
            onChange={(e) => handleChange('type', e.target.value as TransactionType)}
          >
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Amount</label>
          <input
            type="number"
            className="w-full p-2 rounded border bg-transparent"
            value={value.amount}
            onChange={(e) => handleChange('amount', parseFloat(e.target.value))}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Category</label>
        <select
          className="w-full p-2 rounded border bg-transparent"
          value={value.category}
          onChange={(e) => handleChange('category', e.target.value as TransactionCategory)}
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Description (Optional)</label>
        <input
          type="text"
          className="w-full p-2 rounded border bg-transparent"
          value={value.description || ''}
          onChange={(e) => handleChange('description', e.target.value)}
          placeholder="Add a description..."
        />
      </div>
    </div>
  );
};

export default FinancialEntryForm; 