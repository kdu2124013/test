import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { DiaryStatistics, TransactionCategory } from '@/types/diary';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface FinancialStatsProps {
  stats: DiaryStatistics;
}

export const FinancialStats: React.FC<FinancialStatsProps> = ({ stats }) => {
  const categoryData = {
    labels: Object.keys(stats.categoryBreakdown),
    datasets: [
      {
        data: Object.values(stats.categoryBreakdown),
        backgroundColor: [
          '#FF6384',
          '#36A2EB',
          '#FFCE56',
          '#4BC0C0',
          '#9966FF',
          '#FF9F40',
          '#FF6384',
          '#C9CBCF'
        ]
      }
    ]
  };

  const summaryData = {
    labels: ['Income', 'Expense', 'Net'],
    datasets: [
      {
        label: 'Amount',
        data: [stats.totalIncome, stats.totalExpense, stats.netAmount],
        backgroundColor: ['#4BC0C0', '#FF6384', '#36A2EB']
      }
    ]
  };

  return (
    <div className="space-y-6 p-4">
      <div className="grid grid-cols-3 gap-4">
        <div className="p-4 border rounded-lg">
          <h4 className="text-lg font-semibold">Total Income</h4>
          <p className="text-2xl text-green-500">₩{stats.totalIncome.toLocaleString()}</p>
        </div>
        <div className="p-4 border rounded-lg">
          <h4 className="text-lg font-semibold">Total Expense</h4>
          <p className="text-2xl text-red-500">₩{stats.totalExpense.toLocaleString()}</p>
        </div>
        <div className="p-4 border rounded-lg">
          <h4 className="text-lg font-semibold">Net Amount</h4>
          <p className={`text-2xl ${stats.netAmount >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            ₩{stats.netAmount.toLocaleString()}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 border rounded-lg">
          <h4 className="text-lg font-semibold mb-4">Summary</h4>
          <Bar data={summaryData} />
        </div>
        <div className="p-4 border rounded-lg">
          <h4 className="text-lg font-semibold mb-4">Category Breakdown</h4>
          <Pie data={categoryData} />
        </div>
      </div>

      <div className="p-4 border rounded-lg">
        <h4 className="text-lg font-semibold mb-2">Period</h4>
        <p>
          {new Date(stats.periodStart).toLocaleDateString()} -{' '}
          {new Date(stats.periodEnd).toLocaleDateString()}
        </p>
      </div>
    </div>
  );
};

export default FinancialStats; 