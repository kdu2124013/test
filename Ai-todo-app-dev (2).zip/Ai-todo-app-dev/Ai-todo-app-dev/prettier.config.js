// prettier 배포 시 에러 방지
module.exports = {
  plugins: ["prettier-plugin-tailwindcss"],
};
